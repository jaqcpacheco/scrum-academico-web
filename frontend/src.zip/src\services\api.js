export const BASE_URL =
  `${import.meta.env.VITE_API_URL}/api`;

export async function getBoards() {

  const res =
    await fetch(
      `${BASE_URL}/boards`
    );

  const json =
    await res.json();

  return json?.data;
}

export async function getMetrics(boardId) {

  const res =
    await fetch(
      `${BASE_URL}/metrics/${boardId}`
    );

  const json =
    await res.json();

  return json?.data;
}