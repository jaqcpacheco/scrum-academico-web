export default function SidebarItem({
  icon,
  title,
  active = false,
  onClick
}) {

  return (

    <button
      onClick={onClick}
      className={`
        w-full
        flex items-center
        gap-2
        px-3
        py-1
        rounded-lg
        transition-all
        duration-300

        ${
          active

            ? `
              bg-gradient-to-r
              from-blue-600/30
              to-violet-600/20
              border border-blue-500/20
              shadow-[0_0_25px_rgba(59,130,246,.15)]
              text-white
            `

            : `
              text-slate-400
              hover:bg-white/5
              hover:text-white
            `
        }
      `}
    >

      {/* ÍCONE */}
      <span className="text-base">

        {icon}

      </span>

      {/* TEXTO */}
      <span className="
        text-sm
        font-medium
      ">

        {title}

      </span>

    </button>

  );
}