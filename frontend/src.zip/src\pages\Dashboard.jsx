import { useState, useEffect } from "react";

import AppLayout from "../layout/AppLayout";

import { signOut } from "firebase/auth";
import { auth } from "../services/firebase";

import Card from "../components/Card";
import Chart from "../components/Chart";
import TeamChart from "../components/TeamChart";
import InsightsPanel from "../components/InsightsPanel";
import TeamPerformance from "../components/TeamPerformance";
import { BASE_URL } from "./services/api.js";

import html2pdf from "html2pdf.js";

export default function Dashboard({
  boards,
  selectedBoard,
  setSelectedBoard,
  metrics,
  loading,
  goToHistorico,
  systemUser,
  user,
}) {
  const [activePage, setActivePage] = useState("boards");

  const [historico, setHistorico] = useState([]);

  const [boardsMetrics, setBoardsMetrics] = useState({});

  useEffect(() => {
    const carregarHistorico = async () => {
      try {
        const savedUser = JSON.parse(localStorage.getItem("user"));

        const res = await fetch(
          `${BASE_URL}/history?userId=${savedUser?.uid}`,
        );

        const data = await res.json();

        setHistorico(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error("Erro histórico:", err);
      }
    };

    carregarHistorico();
  }, []);

  useEffect(() => {
    async function carregarBoardsMetrics() {
      try {
        const resultados = {};

        for (const board of boards) {
          try {
            const res = await fetch(`${BASE_URL}/metrics/${board.id}`);

            const data = await res.json();

            resultados[board.id] = data?.data || null;
          } catch {
            resultados[board.id] = null;
          }
        }

        setBoardsMetrics(resultados);
      } catch (error) {
        console.error("Erro boards metrics:", error);
      }
    }

    if (boards?.length > 0) {
      carregarBoardsMetrics();
    }
  }, [boards]);

  const gerarPDF = () => {
    if (!metrics) {
      console.log("Nenhuma métrica disponível para exportar.");
      return;
    }
    console.log("Métricas disponíveis para exportar:", metrics);

    const element = document.createElement("div");

    element.innerHTML = `
      <div style="font-family:Arial;padding:30px;">

        <h1>Relatório Project Minds</h1>

        <hr/>

        <h2>Métricas Scrum</h2>

        <p>Total: ${metrics.total}</p>
        <p>Concluídas: ${metrics.concluidas}</p>
        <p>Em andamento: ${metrics.emAndamento}</p>
        <p>Backlog: ${metrics.backlog}</p>
        <p>Produtividade: ${metrics.produtividade}%</p>

        <hr/>

        <h2>Kanban</h2>

        <p>WIP: ${metrics.wip}</p>
        <p>Status: ${metrics.wipStatus}</p>

        <hr/>

        <h2>Insight IA</h2>

        <p>${metrics.insight}</p>

      </div>
    `;

    html2pdf().from(element).save("relatorio-projectminds.pdf");
  };

  const logout = async () => {
    try {
      await signOut(auth);

      localStorage.clear();

      window.location.reload();
    } catch (error) {
      console.error("Erro logout:", error);
    }
  };

  return (
    <AppLayout
      systemUser={systemUser}
      user={user}
      goToHistorico={goToHistorico}
      activePage={activePage}
      setActivePage={setActivePage}
      setSelectedBoard={setSelectedBoard}
      gerarPDF={gerarPDF}
      logout={logout}
    >
      <div id="relatorio">
        {loading && (
          <p
            className="
            text-slate-400
            text-sm
            mb-6
            animate-pulse
          "
          >
            ⏳ Carregando análise...
          </p>
        )}

        {!selectedBoard && (
          <div>
            <div
              className="
              flex items-center
              justify-between
              mb-10
            "
            >
              <div>
                <h1
                  className="
                  text-5xl
                  font-bold
                  mb-3
                  text-white
                "
                >
                  Boards
                </h1>

                <p
                  className="
                  text-slate-400
                  text-lg
                "
                >
                  Gerencie os workspaces da equipe
                </p>
              </div>
            </div>

            <div
              className="
              grid
              grid-cols-1
              md:grid-cols-2
              xl:grid-cols-3
              gap-5
            "
            >
              {boards.map((board) => (
                <button
                  key={board.id}
                  onClick={() => {
                    setSelectedBoard(board.id);

                    setActivePage("performance");
                  }}
                  className="
                    text-left
                    p-5
                    rounded-2xl
                    border border-white/5
                    bg-white/[0.03]
                    hover:bg-white/[0.05]
                    hover:border-blue-500/30
                    hover:shadow-[0_0_30px_rgba(59,130,246,.08)]
                    transition-all
                    group
                  "
                >
                  <div
                    className="
                    flex items-start
                    justify-between
                    mb-5
                  "
                  >
                    <div>
                      <h2
                        className="
                        text-xl
                        font-semibold
                        mb-2
                        text-white
                      "
                      >
                        {board.name}
                      </h2>

                      <p
                        className="
                        text-slate-400
                        text-sm
                      "
                      >
                        Workspace Scrum/Kanban
                      </p>
                    </div>

                    <div
                      className="
                      text-2xl
                      opacity-70
                      group-hover:translate-x-1
                      transition-all
                    "
                    >
                      →
                    </div>
                  </div>

                  <div
                    className="
                    grid
                    grid-cols-2
                    gap-4
                    mt-6
                  "
                  >
                    <div>
                      <p
                        className="
                        text-slate-500
                        text-xs
                        mb-1
                      "
                      >
                        Produtividade
                      </p>

                      <h3
                        className="
                        text-emerald-400
                        font-bold
                        text-lg
                      "
                      >
                        {boardsMetrics[board.id]?.produtividade || 0}%
                      </h3>
                    </div>

                    <div>
                      <p
                        className="
                        text-slate-500
                        text-xs
                        mb-1
                      "
                      >
                        Tasks
                      </p>

                      <h3
                        className="
                        text-white
                        font-semibold
                        text-lg
                      "
                      >
                        {boardsMetrics[board.id]?.total || 0}
                      </h3>
                    </div>

                    <div>
                      <p
                        className="
                        text-slate-500
                        text-xs
                        mb-1
                      "
                      >
                        Team
                      </p>

                      <h3
                        className="
                        text-white
                        font-semibold
                        text-lg
                      "
                      >
                        {boardsMetrics[board.id]?.memberMetrics?.length || 0}
                      </h3>
                    </div>

                    <div>
                      <p
                        className="
                        text-slate-500
                        text-xs
                        mb-1
                      "
                      >
                        Status
                      </p>

                      <div
                        className="
                        inline-flex
                        px-3 py-1
                        rounded-full
                        bg-emerald-500/20
                        text-emerald-400
                        text-xs
                      "
                      >
                        Healthy
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {!selectedBoard && activePage !== "boards" && (
          <div
            className="
    flex
    flex-col
    items-center
    justify-center
    text-center
    py-24
  "
          >
            <div className="text-6xl mb-6">📂</div>

            <h2
              className="
      text-3xl
      font-bold
      text-white
      mb-3
    "
            >
              Nenhum board selecionado
            </h2>

            <p
              className="
                text-slate-400
                max-w-md
              "
            >
              Selecione um board para visualizar métricas, insights e desempenho
              da equipe.
            </p>
          </div>
        )}
        {selectedBoard && metrics && (
          <>
            <div
              className="
              flex items-center
              justify-between
              mb-10
            "
            >
              <div>
                <h1
                  className="
                  text-4xl
                  font-bold
                  mb-2
                  text-white
                "
                >
                  Project Minds Dashboard
                </h1>

                <p
                  className="
                  text-slate-400
                "
                >
                  Métricas e insights em tempo real
                </p>
              </div>

              <button
                onClick={() => {
                  setSelectedBoard("");

                  setActivePage("boards");
                }}
                className="
                  px-5 py-3
                  rounded-2xl
                  bg-white/5
                  border border-white/10
                  hover:bg-white/10
                  transition-all
                "
              >
                ← Voltar aos boards
              </button>
            </div>

            {activePage === "performance" && (
              <>
                {/* KPI */}
                <div
                  className="
                  grid
                  grid-cols-1
                  md:grid-cols-5
                  gap-6
                "
                >
                  <Card title="Total" value={metrics.total} />

                  <Card title="Backlog" value={metrics.backlog} />

                  <Card title="Em progresso" value={metrics.emAndamento} />

                  <Card title="Concluídas" value={metrics.concluidas} />

                  <Card
                    title="Produtividade"
                    value={`${metrics.produtividade}%`}
                  />
                </div>

                <div
                  className="
                  grid
                  grid-cols-1
                  md:grid-cols-3
                  gap-6
                  mt-10
                "
                >
                  <Card
                    title="WIP"
                    value={`${metrics.wip} / ${metrics.wipLimit}`}
                    subtitle={`${metrics.wipPercent}%`}
                  />

                  <Card title="Eficiência" value={metrics.eficiencia} />

                  <Card title="Backlog" value={metrics.backlog} />
                </div>

                <div
                  className="
                  grid
                  grid-cols-1
                  xl:grid-cols-2
                  gap-6
                  mt-10
                "
                >
                  <Chart
                    data={
                      historico.length > 0
                        ? historico.map((item) => ({
                            dia: new Date(item.createdAt).toLocaleDateString(),

                            valor: item.concluidas,
                          }))
                        : []
                    }
                  />

                  <TeamChart
                    data={[
                      {
                        nome: "Concluídas",
                        quantidade: metrics.concluidas,
                      },

                      {
                        nome: "Em andamento",
                        quantidade: metrics.emAndamento,
                      },

                      {
                        nome: "Backlog",
                        quantidade: metrics.backlog,
                      },
                    ]}
                  />
                </div>

                <div className="mt-10">
                  <TeamPerformance members={metrics.memberMetrics || []} />
                </div>
              </>
            )}

            {activePage === "insights" && (
              <div className="mt-6">
                <InsightsPanel metrics={metrics} />
              </div>
            )}
            
            {activePage === "team" && (
              <div className="mt-6">
                <TeamPerformance members={metrics?.memberMetrics || []} />
              </div>
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
}
