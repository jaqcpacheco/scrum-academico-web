export default function UserCard({
  systemUser,
  user
}) {

  return (

    <div className="
      bg-white/[0.03]
      border border-white/5
      rounded-2xl
      p-2
      flex items-center
      gap-4
      backdrop-blur-xl
    ">

      {/* AVATAR */}
      <div className="
        w-10h-10
        rounded-full
        bg-gradient-to-br
        from-violet-500
        to-blue-500
        flex items-center
        justify-center
        text-white
        font-bold
        shadow-lg
      ">

        {
          systemUser?.nome?.[0]
          || user?.displayName?.[0]
          || "J"
        }

      </div>

      {/* INFO */}
      <div className="flex-1 min-w-0">

        <h3 className="
          font-medium text-sm
          text-white
          truncate
        ">

          {
            systemUser?.nome
            || user?.displayName
          }

        </h3>

        <p className="
          text-sm
          text-slate-400
        ">

          Agile Manager

        </p>

      </div>

    </div>

  );
}