import SidebarItem from "./SidebarItem";
import UserCard from "./UserCard";
import { BASE_URL } from "./services/api.js";

export default function Sidebar({
  systemUser,
  user,
  goToHistorico,
  activePage = "boards",
  setActivePage,
  setSelectedBoard,
  gerarPDF,
  logout
}) {

  return (

    <aside className="
      w-[250px]
      min-h-screen
      border-r border-white/5
      bg-[#060816]
      flex flex-col
      justify-between
      p-6
    ">

      {/* TOPO */}
      <div>

        {/* LOGO */}
        <div className="
          flex items-center
          gap-3
          mb-10
        ">

          <div className="
            w-12 h-12
            rounded-2xl
            bg-gradient-to-br
            from-violet-500
            to-cyan-400
            flex items-center
            justify-center
            text-xl
            shadow-lg
          ">

            ⚡

          </div>

          <div>

            <h1 className="
              text-2xl
              font-bold
              text-white
              leading-tight
            ">

              Project Minds

            </h1>

            <p className="
              text-xs
              text-slate-400
              leading-relaxed
            ">

              Smart Agile Intelligence

            </p>

          </div>

        </div>

        {/* MENU */}
        <nav className="
          space-y-1
          mt-6
        ">

          <SidebarItem
            icon="📂"
            title="Boards"
            active={activePage === "boards"}
            onClick={() => {

  setSelectedBoard("");

  setActivePage("boards");

}}
            
          />

          <SidebarItem
            icon="✨"
            title="Insights"
            active={activePage === "insights"}
            onClick={() =>
              setActivePage("insights")
            }
          />

          <SidebarItem
            icon="📈"
            title="Performance"
            active={activePage === "performance"}
            onClick={() =>
              setActivePage("performance")
            }
          />

          <SidebarItem
            icon="👥"
            title="Team"
            active={activePage === "team"}
            onClick={() =>
              setActivePage("team")
            }
          />

          <SidebarItem
            icon="📁"
            title="Histórico"
            active={activePage === "historico"}
            onClick={() => {

              setActivePage("historico");

              goToHistorico();

            }}
          />

        </nav>

        {/* AÇÕES */}
        <div className="
          mt-10
          pt-6
          border-t border-white/5
          space-y-1
        ">

          <SidebarItem
            icon="📄"
            title="Exportar PDF"
            onClick={gerarPDF}
          />

          <SidebarItem
            icon="🚪"
            title="Sair"
            onClick={logout}
          />

          <SidebarItem
            icon="🔌"
            title="Desconectar Trello"
            onClick={async () => {

    try {

      const user =
        JSON.parse(
          localStorage.getItem("user")
        );

      const response =
        await fetch(

          `${BASE_URL}/users/disconnect-trello`,

          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json"
            },

            body: JSON.stringify({

              userId: user.uid
            })
          }
        );

      const data =
        await response.json();

      localStorage.setItem(
        "user",
        JSON.stringify(data.user)
      );

      window.location.reload();

    } catch (error) {

      console.error(error);

    }
  }}
/>
        </div>

      </div>

      {/* USUÁRIO */}
      <UserCard
        systemUser={systemUser}
        user={user}
      />

    </aside>
  );
}